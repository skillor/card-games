choose( /* {"x": -250, "y":0} */
  currentPlayer() /* {"x": -500, "y":0} */,
  ToArray( /* {"x": -500, "y":220} */
    textOption( /* {"x": -750, "y":220} */
      of("Diamonds") /* {"x": -1000, "y":220} */,
      of((
        ) => setGameVariable( /* {"x": -1000, "y":440} */
        of("lastFace") /* {"x": -1250, "y":440} */,
        of("D") /* {"x": -1250, "y":660} */
      ))
    ),
    textOption( /* {"x": -750, "y":880} */
      of("Hearts") /* {"x": -1000, "y":880} */,
      of((
        ) => setGameVariable( /* {"x": -1000, "y":1100} */
        of("lastFace") /* {"x": -1250, "y":1100} */,
        of("H") /* {"x": -1250, "y":1320} */
      ))
    ),
    textOption( /* {"x": -750, "y":1540} */
      of("Spades") /* {"x": -1000, "y":1540} */,
      of((
        ) => setGameVariable( /* {"x": -1000, "y":1760} */
        of("lastFace") /* {"x": -1250, "y":1760} */,
        of("S") /* {"x": -1250, "y":1980} */
      ))
    ),
    textOption( /* {"x": -750, "y":2200} */
      of("Clubs") /* {"x": -1000, "y":2200} */,
      of((
        ) => setGameVariable( /* {"x": -1000, "y":2420} */
        of("lastFace") /* {"x": -1250, "y":2420} */,
        of("C") /* {"x": -1250, "y":2640} */
      ))
    )
  ),
  undefined
)