setGameVariable( /* {"x": -250, "y":0} */
  of("playedA") /* {"x": -500, "y":0} */,
  of(true) /* {"x": -500, "y":220} */
)