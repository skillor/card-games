sequential( /* {"x": -250, "y":0} */
  fillStack( /* {"x": -500, "y":0} */
    getGlobalCardStack( /* {"x": -750, "y":0} */
      of("draw") /* {"x": -1000, "y":0} */
    ),
    undefined
  ),
  shuffleStack( /* {"x": -500, "y":220} */
    getGlobalCardStack( /* {"x": -750, "y":220} */
      of("draw") /* {"x": -1000, "y":220} */
    )
  ),
  map( /* {"x": -500, "y":440} */
    players() /* {"x": -750, "y":440} */,
    of((
        x
      ) => sequential( /* {"x": -750, "y":660} */
      moveCards( /* {"x": -1000, "y":660} */
        getGlobalCardStack( /* {"x": -1250, "y":660} */
          of("draw") /* {"x": -1500, "y":660} */
        ),
        getPlayerCardStack( /* {"x": -1250, "y":880} */
          of("hand") /* {"x": -1500, "y":880} */,
          x
        ),
        topCards( /* {"x": -1250, "y":1320} */
          getGlobalCardStack( /* {"x": -1500, "y":1320} */
            of("draw") /* {"x": -1750, "y":1320} */
          ),
          ToString( /* {"x": -1500, "y":1540} */
            getGameVariable( /* {"x": -1750, "y":1540} */
              of("startHandCards") /* {"x": -2000, "y":1540} */
            )
          )
        )
      )
    ))
  ),
  moveCards( /* {"x": -500, "y":1760} */
    getGlobalCardStack( /* {"x": -750, "y":1760} */
      of("draw") /* {"x": -1000, "y":1760} */
    ),
    getGlobalCardStack( /* {"x": -750, "y":1980} */
      of("main") /* {"x": -1000, "y":1980} */
    ),
    topCards( /* {"x": -750, "y":2200} */
      getGlobalCardStack( /* {"x": -1000, "y":2200} */
        of("draw") /* {"x": -1250, "y":2200} */
      ),
      undefined
    )
  ),
  setGameVariable( /* {"x": -500, "y":2420} */
    of("lastFace") /* {"x": -750, "y":2420} */,
    cardType( /* {"x": -750, "y":2640} */
      of("face") /* {"x": -1000, "y":2640} */,
      first( /* {"x": -1000, "y":2860} */
        topCards( /* {"x": -1250, "y":2860} */
          getGlobalCardStack( /* {"x": -1500, "y":2860} */
            of("main") /* {"x": -1750, "y":2860} */
          ),
          undefined
        )
      )
    )
  ),
  runAction( /* {"x": -500, "y":3080} */
    add( /* {"x": -750, "y":3080} */
      of("play") /* {"x": -1000, "y":3080} */,
      cardType( /* {"x": -1000, "y":3300} */
        of("type") /* {"x": -1250, "y":3300} */,
        first( /* {"x": -1250, "y":3520} */
          topCards( /* {"x": -1500, "y":3520} */
            getGlobalCardStack( /* {"x": -1750, "y":3520} */
              of("main") /* {"x": -2000, "y":3520} */
            ),
            undefined
          )
        )
      )
    )
  ),
  setPhase( /* {"x": -500, "y":3740} */
    randomChoice( /* {"x": -750, "y":3740} */
      players() /* {"x": -1000, "y":3740} */
    ),
    of("main") /* {"x": -750, "y":3960} */
  )
)