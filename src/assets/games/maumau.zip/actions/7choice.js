sequential( /* {"x": -250, "y":0} */
  setGameVariable( /* {"x": -500, "y":0} */
    of("7counter") /* {"x": -750, "y":0} */,
    min( /* {"x": -750, "y":220} */
      getGameVariable( /* {"x": -1000, "y":220} */
        of("7counter") /* {"x": -1250, "y":220} */
      ),
      add( /* {"x": -1000, "y":440} */
        length( /* {"x": -1250, "y":440} */
          getCardsOfCardStack( /* {"x": -1500, "y":440} */
            getGlobalCardStack( /* {"x": -1750, "y":440} */
              of("draw") /* {"x": -2000, "y":440} */
            )
          )
        ),
        length( /* {"x": -1250, "y":660} */
          getCardsOfCardStack( /* {"x": -1500, "y":660} */
            getGlobalCardStack( /* {"x": -1750, "y":660} */
              of("main") /* {"x": -2000, "y":660} */
            )
          )
        ),
        of(-1) /* {"x": -1250, "y":880} */
      )
    )
  ),
  choose( /* {"x": -500, "y":1100} */
    currentPlayer() /* {"x": -750, "y":1100} */,
    concat( /* {"x": -750, "y":1320} */
      addCardStackTargets( /* {"x": -1000, "y":1320} */
        cardOptions( /* {"x": -1250, "y":1320} */
          topCards( /* {"x": -1500, "y":1320} */
            getGlobalCardStack( /* {"x": -1750, "y":1320} */
              of("draw") /* {"x": -2000, "y":1320} */
            ),
            undefined
          ),
          of((
              cards
            ) => sequential( /* {"x": -1500, "y":1540} */
            runAction( /* {"x": -1750, "y":1540} */
              of("refill") /* {"x": -2000, "y":1540} */
            ),
            moveCards( /* {"x": -1750, "y":1760} */
              getGlobalCardStack( /* {"x": -2000, "y":1760} */
                of("draw") /* {"x": -2250, "y":1760} */
              ),
              getPlayerCardStack( /* {"x": -2000, "y":1980} */
                of("hand") /* {"x": -2250, "y":1980} */,
                currentPlayer() /* {"x": -2250, "y":2200} */
              ),
              topCards( /* {"x": -2000, "y":2420} */
                getGlobalCardStack( /* {"x": -2250, "y":2420} */
                  of("draw") /* {"x": -2500, "y":2420} */
                ),
                ToNumber( /* {"x": -2250, "y":2640} */
                  getGameVariable( /* {"x": -2500, "y":2640} */
                    of("7counter") /* {"x": -2750, "y":2640} */
                  )
                )
              )
            ),
            setGameVariable( /* {"x": -1750, "y":2860} */
              of("7counter") /* {"x": -2000, "y":2860} */,
              of(0) /* {"x": -2000, "y":3080} */
            )
          ))
        ),
        ToArray( /* {"x": -1250, "y":3300} */
          getPlayerCardStack( /* {"x": -1500, "y":3300} */
            of("hand") /* {"x": -1750, "y":3300} */,
            currentPlayer() /* {"x": -1750, "y":3520} */
          )
        )
      ),
      addCardStackTargets( /* {"x": -1000, "y":3740} */
        cardOptions( /* {"x": -1250, "y":3740} */
          filter( /* {"x": -1500, "y":3740} */
            getCardsOfCardStack( /* {"x": -1750, "y":3740} */
              getPlayerCardStack( /* {"x": -2000, "y":3740} */
                of("hand") /* {"x": -2250, "y":3740} */,
                currentPlayer() /* {"x": -2250, "y":3960} */
              )
            ),
            of((
                con
              ) => equals( /* {"x": -1750, "y":4180} */
              cardType( /* {"x": -2000, "y":4180} */
                of("type") /* {"x": -2250, "y":4180} */,
                con
              ),
              of("7") /* {"x": -2000, "y":4620} */
            ))
          ),
          of((
              cards
            ) => sequential( /* {"x": -1500, "y":4840} */
            moveCards( /* {"x": -1750, "y":4840} */
              getPlayerCardStack( /* {"x": -2000, "y":4840} */
                of("hand") /* {"x": -2250, "y":4840} */,
                currentPlayer() /* {"x": -2250, "y":5060} */
              ),
              getGlobalCardStack( /* {"x": -2000, "y":5280} */
                of("main") /* {"x": -2250, "y":5280} */
              ),
              cards
            ),
            setGameVariable( /* {"x": -1750, "y":5720} */
              of("lastFace") /* {"x": -2000, "y":5720} */,
              cardType( /* {"x": -2000, "y":5940} */
                of("face") /* {"x": -2250, "y":5940} */,
                first( /* {"x": -2250, "y":6160} */
                  cards
                )
              )
            ),
            runAction( /* {"x": -1750, "y":6380} */
              add( /* {"x": -2000, "y":6380} */
                of("play") /* {"x": -2250, "y":6380} */,
                cardType( /* {"x": -2250, "y":6600} */
                  of("type") /* {"x": -2500, "y":6600} */,
                  first( /* {"x": -2500, "y":6820} */
                    cards
                  )
                )
              )
            )
          ))
        ),
        ToArray( /* {"x": -1250, "y":7040} */
          getGlobalCardStack( /* {"x": -1500, "y":7040} */
            of("main") /* {"x": -1750, "y":7040} */
          )
        )
      )
    ),
    undefined
  )
)