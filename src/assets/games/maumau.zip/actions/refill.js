iff( /* {"x": -250, "y":0} */
  lessEquals( /* {"x": -500, "y":0} */
    length( /* {"x": -750, "y":0} */
      getCardsOfCardStack( /* {"x": -1000, "y":0} */
        getGlobalCardStack( /* {"x": -1250, "y":0} */
          of("draw") /* {"x": -1500, "y":0} */
        )
      )
    ),
    max( /* {"x": -750, "y":220} */
      of(1) /* {"x": -1000, "y":220} */,
      ToNumber( /* {"x": -1000, "y":440} */
        getGameVariable( /* {"x": -1250, "y":440} */
          of("7counter") /* {"x": -1500, "y":440} */
        )
      )
    )
  ),
  sequential( /* {"x": -500, "y":660} */
    moveCards( /* {"x": -750, "y":660} */
      getGlobalCardStack( /* {"x": -1000, "y":660} */
        of("main") /* {"x": -1250, "y":660} */
      ),
      getGlobalCardStack( /* {"x": -1000, "y":880} */
        of("draw") /* {"x": -1250, "y":880} */
      ),
      bottomCards( /* {"x": -1000, "y":1100} */
        getGlobalCardStack( /* {"x": -1250, "y":1100} */
          of("main") /* {"x": -1500, "y":1100} */
        ),
        add( /* {"x": -1250, "y":1320} */
          length( /* {"x": -1500, "y":1320} */
            getCardsOfCardStack( /* {"x": -1750, "y":1320} */
              getGlobalCardStack( /* {"x": -2000, "y":1320} */
                of("main") /* {"x": -2250, "y":1320} */
              )
            )
          ),
          of(-1) /* {"x": -1500, "y":1540} */
        )
      )
    ),
    shuffleStack( /* {"x": -750, "y":1760} */
      getGlobalCardStack( /* {"x": -1000, "y":1760} */
        of("draw") /* {"x": -1250, "y":1760} */
      )
    )
  ),
  undefined
)