choose( /* {"x": -250, "y":0} */
  currentPlayer() /* {"x": -500, "y":0} */,
  concat( /* {"x": -500, "y":220} */
    iff( /* {"x": -750, "y":220} */
      equals( /* {"x": -1000, "y":220} */
        of(1) /* {"x": -1250, "y":220} */,
        add( /* {"x": -1250, "y":440} */
          length( /* {"x": -1500, "y":440} */
            getCardsOfCardStack( /* {"x": -1750, "y":440} */
              getGlobalCardStack( /* {"x": -2000, "y":440} */
                of("draw") /* {"x": -2250, "y":440} */
              )
            )
          ),
          length( /* {"x": -1500, "y":660} */
            getCardsOfCardStack( /* {"x": -1750, "y":660} */
              getGlobalCardStack( /* {"x": -2000, "y":660} */
                of("main") /* {"x": -2250, "y":660} */
              )
            )
          )
        )
      ),
      emptyOptions() /* {"x": -1000, "y":880} */,
      addCardStackTargets( /* {"x": -1000, "y":1100} */
        cardOptions( /* {"x": -1250, "y":1100} */
          topCards( /* {"x": -1500, "y":1100} */
            getGlobalCardStack( /* {"x": -1750, "y":1100} */
              of("draw") /* {"x": -2000, "y":1100} */
            ),
            undefined
          ),
          of((
              cards
            ) => sequential( /* {"x": -1500, "y":1320} */
            moveCards( /* {"x": -1750, "y":1320} */
              getGlobalCardStack( /* {"x": -2000, "y":1320} */
                of("draw") /* {"x": -2250, "y":1320} */
              ),
              getPlayerCardStack( /* {"x": -2000, "y":1540} */
                of("hand") /* {"x": -2250, "y":1540} */,
                currentPlayer() /* {"x": -2250, "y":1760} */
              ),
              topCards( /* {"x": -2000, "y":1980} */
                getGlobalCardStack( /* {"x": -2250, "y":1980} */
                  of("draw") /* {"x": -2500, "y":1980} */
                ),
                undefined
              )
            )
          ))
        ),
        ToArray( /* {"x": -1250, "y":2200} */
          getPlayerCardStack( /* {"x": -1500, "y":2200} */
            of("hand") /* {"x": -1750, "y":2200} */,
            currentPlayer() /* {"x": -1750, "y":2420} */
          )
        )
      )
    ),
    addCardStackTargets( /* {"x": -750, "y":2640} */
      cardOptions( /* {"x": -1000, "y":2640} */
        filter( /* {"x": -1250, "y":2640} */
          getCardsOfCardStack( /* {"x": -1500, "y":2640} */
            getPlayerCardStack( /* {"x": -1750, "y":2640} */
              of("hand") /* {"x": -2000, "y":2640} */,
              currentPlayer() /* {"x": -2000, "y":2860} */
            )
          ),
          of((
              con
            ) => or( /* {"x": -1500, "y":3080} */
            equals( /* {"x": -1750, "y":3080} */
              cardType( /* {"x": -2000, "y":3080} */
                of("face") /* {"x": -2250, "y":3080} */,
                con
              ),
              ToString( /* {"x": -2000, "y":3520} */
                getGameVariable( /* {"x": -2250, "y":3520} */
                  of("lastFace") /* {"x": -2500, "y":3520} */
                )
              )
            ),
            equals( /* {"x": -1750, "y":3740} */
              cardType( /* {"x": -2000, "y":3740} */
                of("type") /* {"x": -2250, "y":3740} */,
                con
              ),
              cardType( /* {"x": -2000, "y":4180} */
                of("type") /* {"x": -2250, "y":4180} */,
                first( /* {"x": -2250, "y":4400} */
                  topCards( /* {"x": -2500, "y":4400} */
                    getGlobalCardStack( /* {"x": -2750, "y":4400} */
                      of("main") /* {"x": -3000, "y":4400} */
                    ),
                    undefined
                  )
                )
              )
            ),
            equals( /* {"x": -1750, "y":4620} */
              cardType( /* {"x": -2000, "y":4620} */
                of("type") /* {"x": -2250, "y":4620} */,
                con
              ),
              of("J") /* {"x": -2000, "y":5060} */
            )
          ))
        ),
        of((
            cards
          ) => sequential( /* {"x": -1250, "y":5280} */
          setGameVariable( /* {"x": -1500, "y":5280} */
            of("lastFace") /* {"x": -1750, "y":5280} */,
            cardType( /* {"x": -1750, "y":5500} */
              of("face") /* {"x": -2000, "y":5500} */,
              first( /* {"x": -2000, "y":5720} */
                cards
              )
            )
          ),
          runAction( /* {"x": -1500, "y":5940} */
            add( /* {"x": -1750, "y":5940} */
              of("play") /* {"x": -2000, "y":5940} */,
              cardType( /* {"x": -2000, "y":6160} */
                of("type") /* {"x": -2250, "y":6160} */,
                first( /* {"x": -2250, "y":6380} */
                  cards
                )
              )
            )
          ),
          moveCards( /* {"x": -1500, "y":6600} */
            getPlayerCardStack( /* {"x": -1750, "y":6600} */
              of("hand") /* {"x": -2000, "y":6600} */,
              currentPlayer() /* {"x": -2000, "y":6820} */
            ),
            getGlobalCardStack( /* {"x": -1750, "y":7040} */
              of("main") /* {"x": -2000, "y":7040} */
            ),
            cards
          )
        ))
      ),
      ToArray( /* {"x": -1000, "y":7480} */
        getGlobalCardStack( /* {"x": -1250, "y":7480} */
          of("main") /* {"x": -1500, "y":7480} */
        )
      )
    )
  ),
  undefined
)