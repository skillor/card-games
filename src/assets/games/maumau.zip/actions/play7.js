setGameVariable( /* {"x": -250, "y":0} */
  of("7counter") /* {"x": -500, "y":0} */,
  add( /* {"x": -500, "y":220} */
    ToNumber( /* {"x": -750, "y":220} */
      getGameVariable( /* {"x": -1000, "y":220} */
        of("7counter") /* {"x": -1250, "y":220} */
      )
    ),
    of(2) /* {"x": -750, "y":440} */
  )
)