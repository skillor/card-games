sequential( /* {"x": -250, "y":0} */
  fillStack( /* {"x": -500, "y":0} */
    getGlobalCardStack( /* {"x": -750, "y":0} */
      of("draw") /* {"x": -1000, "y":0} */
    ),
    undefined
  ),
  shuffleStack( /* {"x": -500, "y":220} */
    getGlobalCardStack( /* {"x": -750, "y":220} */
      of("draw") /* {"x": -1000, "y":220} */
    )
  ),
  first( /* {"x": -502, "y":366} */
    map( /* {"x": -660, "y":478} */
      players() /* {"x": -938, "y":438} */,
      of((
          x
        ) => moveCards( /* {"x": -1000, "y":660} */
        getGlobalCardStack( /* {"x": -1250, "y":660} */
          of("draw") /* {"x": -1500, "y":660} */
        ),
        getPlayerCardStack( /* {"x": -1250, "y":880} */
          of("hand") /* {"x": -1500, "y":880} */,
          x
        ),
        topCards( /* {"x": -1250, "y":1320} */
          getGlobalCardStack( /* {"x": -1500, "y":1320} */
            of("draw") /* {"x": -1750, "y":1320} */
          ),
          ToNumber( /* {"x": -1511, "y":1557} */
            getGameVariable( /* {"x": -1750, "y":1540} */
              of("handCards") /* {"x": -2000, "y":1540} */
            )
          )
        )
      ))
    )
  ),
  moveCards( /* {"x": -500, "y":1760} */
    getGlobalCardStack( /* {"x": -750, "y":1760} */
      of("draw") /* {"x": -1000, "y":1760} */
    ),
    getGlobalCardStack( /* {"x": -750, "y":1980} */
      of("main") /* {"x": -1000, "y":1980} */
    ),
    topCards( /* {"x": -750, "y":2200} */
      getGlobalCardStack( /* {"x": -1000, "y":2200} */
        of("draw") /* {"x": -1250, "y":2200} */
      ),
      ToNumber( /* {"x": -1016, "y":2402} */
        getGameVariable( /* {"x": -1250, "y":2420} */
          of("handCards") /* {"x": -1500, "y":2420} */
        )
      )
    )
  ),
  setPhase( /* {"x": -500, "y":2640} */
    randomChoice( /* {"x": -750, "y":2640} */
      players() /* {"x": -1000, "y":2640} */
    ),
    of("main") /* {"x": -750, "y":2860} */
  )
)