choose( /* {"x": -250, "y":0} */
  currentPlayer() /* {"x": -500, "y":0} */,
  cardOptions( /* {"x": -500, "y":220} */
    getCardsOfCardStack( /* {"x": -750, "y":220} */
      getGlobalCardStack( /* {"x": -1000, "y":220} */
        of("main") /* {"x": -1250, "y":220} */
      )
    ),
    of((
        cards
      ) => sequential( /* {"x": -750, "y":440} */
      swapCards( /* {"x": -1000, "y":440} */
        getGlobalCardStack( /* {"x": -1250, "y":440} */
          of("main") /* {"x": -1500, "y":440} */
        ),
        getPlayerCardStack( /* {"x": -1250, "y":660} */
          of("hand") /* {"x": -1500, "y":660} */,
          currentPlayer() /* {"x": -1500, "y":880} */
        ),
        undefined,
        undefined
      ),
      setPhase( /* {"x": -1000, "y":1100} */
        nextPlayer() /* {"x": -1250, "y":1100} */,
        of("main") /* {"x": -1250, "y":1320} */
      )
    ))
  ),
  undefined
)